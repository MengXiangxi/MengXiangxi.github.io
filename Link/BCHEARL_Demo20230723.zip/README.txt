Demo data for BCH EARL

This is the demo data for the BCH EARL program (https://mengxiangxi.info/Link/BCH_EARL.html).

Some of the data have been obtained from `NEMA IQ phantom raw data GE 4-ring DMI' (https://zenodo.org/record/6402885). 

Xiangxi Meng from Beijing Cancer Hospital, mengxiangxi _AT_ pku.edu.cn

20230723

License: CC BY 4.0 https://creativecommons.org/licenses/by/4.0/legalcode